
package evaluacion1;

public class Evaluacion1 {

    public static void main(String[] args) {
         new ventana().setVisible(true);
    }
    
}
