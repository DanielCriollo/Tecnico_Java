
package app3_areatriangulo;

public class App3_AreaTriangulo {

    public static void main(String[] args) {
          new ventana().setVisible(true);
    }
    
}
